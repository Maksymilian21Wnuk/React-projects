### Settings lab
Main goal of this lab is to make good looking 
and accessible form for changing account settings using
Radix Primitives component library.
